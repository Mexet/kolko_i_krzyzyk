﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kolko_i_krzyzyk
{
    public class Player
    {
        private string playerName;
        private int points = 0;
        public Player(string name)
        {
            this.playerName = name;
        }

        public string getName()
        {
            return playerName;
        }

        public int addPoints() 
        {
            this.points += 10;
            return this.points;
        }
    }
}
