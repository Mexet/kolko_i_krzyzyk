﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kolko_i_krzyzyk
{
    public partial class Form2 : Form
    {
        Form form1;
        Player PlayerOne;
        Player PlayerTwo;
        string player1;
        string player2;
        public Form2(Player getPlayerOne, Player getPlayerTwo, Form getForm1)
        {
            InitializeComponent();
            this.form1 = getForm1;
            this.PlayerOne = getPlayerOne;
            this.PlayerTwo = getPlayerTwo;
            player1 = PlayerOne.getName();
            player2 = PlayerTwo.getName();
            playerLabel.Text = player1;
        }

        private bool win()
        {
            if (button1.Text == button2.Text && button1.Text == button3.Text && button1.Text + button2.Text + button3.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button1.Text == button5.Text && button1.Text == button9.Text && button1.Text + button5.Text + button9.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button1.Text == button4.Text && button1.Text == button7.Text && button1.Text + button4.Text + button7.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button2.Text == button5.Text && button2.Text == button8.Text && button2.Text + button5.Text + button8.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button3.Text == button6.Text && button3.Text == button9.Text && button3.Text + button6.Text + button9.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button3.Text == button5.Text && button3.Text == button7.Text && button3.Text + button5.Text + button7.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button4.Text == button5.Text && button4.Text == button6.Text && button4.Text + button5.Text + button6.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button7.Text == button8.Text && button7.Text == button9.Text && button7.Text + button8.Text + button9.Text != "")
                winner.Text = "Zwyciężył gracz: " + playerLabel.Text;
            else if (button1.Text != "" && button2.Text != "" && button3.Text != "" && button4.Text != "" && button5.Text != "" && button6.Text != "" && button7.Text != "" && button8.Text != "" && button9.Text != "")
                winner.Text = "Remis";

            if (winner.Text != "" && winner.Text != "Remis")
            {
                button1.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
                button6.Enabled = false;
                button7.Enabled = false;
                button8.Enabled = false;
                button9.Enabled = false;
                btnAgain.Visible = true;
                return true;
            }
            else if (winner.Text == "Remis")
            {
                btnAgain.Visible = true;
                return true;
            }
                
            return false;
        }

        private void playerMove(Button button)
        {
            if (playerLabel.Text == player1)
            {
                button.Text = "X";
                button.Enabled = false;
                if(win()==true)
                    player1Points.Text = "Punkty gracza " + player1 + ": " + PlayerOne.addPoints().ToString();
                playerLabel.Text = player2;
            }
            else if (playerLabel.Text == player2)
            {
                button.Text = "O";
                button.Enabled = false;
                if (win() == true)
                    player2Points.Text = "Punkty gracza " + player2 + ": " + PlayerTwo.addPoints().ToString();
                playerLabel.Text = player1;
            }
        }

        private void label1_Click_(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            playerMove(button1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            playerMove(button2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            playerMove(button3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            playerMove(button4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            playerMove(button5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            playerMove(button6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            playerMove(button7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            playerMove(button8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            playerMove(button9);
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Czy na pewno chcesz opuścić grę?", "Zamknij", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                form1.Close();
                Application.Exit();
            }
            else if (dialog == DialogResult.No)
                e.Cancel = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnAgain_Click(object sender, EventArgs e)
        {
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            winner.Text = "";
            btnAgain.Visible = false;
        }
    }
}
