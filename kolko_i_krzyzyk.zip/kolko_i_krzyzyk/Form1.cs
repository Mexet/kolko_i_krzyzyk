﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kolko_i_krzyzyk
{
    public partial class Form1 : Form
    {
        Player PlayerOne;
        Player PlayerTwo;
        public Form1()
        {
            InitializeComponent();
        }

        private void play_Click(object sender, EventArgs e)
        {
            if (player1.Text == "" || player2.Text == "" || player1.Text == player2.Text)
            {
                MessageBox.Show("Nazwa żadnego z graczy nie może być pusta lub taka sama");
            }
            else
            {
                PlayerOne = new Player(player1.Text);
                PlayerTwo = new Player(player2.Text);
                Form2 to = new Form2(PlayerOne, PlayerTwo, this);
                to.Show();
                this.Hide();
            }
        }
    }
}
